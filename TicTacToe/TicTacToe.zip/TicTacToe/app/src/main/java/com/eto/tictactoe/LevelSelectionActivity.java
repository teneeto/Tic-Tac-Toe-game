package com.eto.tictactoe;

import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Toast;

public class LevelSelectionActivity extends AppCompatActivity {

    private Bundle extras;
    private String mode;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_level_selection);

        extras = getIntent().getExtras();

        mode = extras.getString("mode").toString();

        Toast.makeText(this, mode, Toast.LENGTH_SHORT).show();
    }

    public void loadGameActivty(View view) {
        int id = view.getId();

        if(id == R.id.threebythree){
            if(mode.equals("single")){
                //Go to single player activity
                Intent intent = new Intent(this, Single3x3.class);
                intent.setFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP);
                startActivity(intent);
            }else if(mode.equals("multi")){
                Toast.makeText(this, "3x3", Toast.LENGTH_SHORT).show();
                Intent intent = new Intent(this, Multi3x3.class);
                intent.setFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP);
                startActivity(intent);
            }

        }else if(id == R.id.fivebyfive){
            if(mode.equals("single")){
                //Go to single 5x5
                Intent intent = new Intent(this, Single5x5.class);
                intent.setFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP);
                startActivity(intent);
            }else if(mode.equals("multi")){
                Toast.makeText(this, "5x5", Toast.LENGTH_SHORT).show();
                Intent intent = new Intent(this, Multi5x5.class);
                intent.setFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP);
                startActivity(intent);
                //startActivity(new Intent(this, Multi5x5.class));
            }


        }else if(id == R.id.fourbyfour){
            if(mode.equals("single")){
                //Go to single 4x4
                Intent intent = new Intent(this, Single4x4.class);
                intent.setFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP);
                startActivity(intent);
            }else if(mode.equals("multi")){
                Toast.makeText(this, "4x4", Toast.LENGTH_SHORT).show();
                Intent intent = new Intent(this, Multi4x4.class);
                intent.setFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP);
                startActivity(intent);
                //startActivity(new Intent(this, Multi5x5.class));
            }

        }
    }
}
